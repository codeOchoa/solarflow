function isBrowser() {
    return typeof window !== "undefined";
}

export default isBrowser;