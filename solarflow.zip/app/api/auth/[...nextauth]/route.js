import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import GithubProvider from "next-auth/providers/github";
import { getFirestore, collection, getDocs } from "firebase/firestore";
import { app } from "@/firebase/config";
import bcrypt from "bcryptjs";

const db = getFirestore(app);

export const authOptions = {
    // Configure one or more authentication providers
    providers: [
        CredentialsProvider({
            id: "credentials",
            name: "Credentials",
            credentials: {
                email: { label: "Email", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                const usersSnapshot = await getDocs(collection(db, "users"));
                const user = usersSnapshot.docs
                    .map((doc) => ({ id: doc.id, ...doc.data() }))
                    .find((u) => u.email === credentials.email);

                if (user && await bcrypt.compare(credentials.password, user.password)) {
                    return {
                        id: user.id,
                        email: user.email,
                    };
                }

                return null;
            },
        }),
        GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        }),
        GithubProvider({
            clientId: process.env.GITHUB_CLIENT_ID,
            clientSecret: process.env.GITHUB_CLIENT_SECRET,
        }),
        // ...add more providers here if you want. You can find them on nextauth website.
    ],
    pages: {
        signIn: "/login",
    },
    session: {
        strategy: "jwt",
    },
    secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };