import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getFirestore, collection, getDocs, addDoc } from "firebase/firestore";
import { app } from "@/firebase/config";

const db = getFirestore(app);

export const POST = async (request) => {
    const { email, password } = await request.json();

    const usersSnapshot = await getDocs(collection(db, "users"));
    const existingUser = usersSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .find(user => user.email === email);

    if (existingUser) {
        return new NextResponse("Email is already in use", { status: 400 });
    }

    const hashedPassword = await bcrypt.hash(password, 5);

    try {
        await addDoc(collection(db, "users"), {
            email,
            password: hashedPassword,
        });

        return new NextResponse("User is registered", { status: 200 });
    } catch (err) {
        return new NextResponse(err.message || "Internal Server Error", {
            status: 500,
        });
    }
};